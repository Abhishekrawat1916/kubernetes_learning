package main

import (
	"bufio"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

type MemoryStats struct {
	Zone string
	// Contains many more fields not listed in this example.
}

func (c *MemoryStats) collectFromFile() (
	oomCountByHost map[string]int, ramUsageByHost map[string]float64,
) {
	// Just example fake data.
	oomCountByHost = map[string]int{
		"foo.example.org": 42,
		"bar.example.org": 2001,
	}
	ramUsageByHost = map[string]float64{
		"foo.example.org": 6.023e23,
		"bar.example.org": 3.14,
	}
	return
}

type MemoryStatsCollector struct {
	MemoryStats *MemoryStats
}

var (
	oomCountDesc = prometheus.NewDesc(
		"MemoryStats_oom_crashes_total",
		"Number of OOM crashes.",
		[]string{"host"}, nil,
	)
	ramUsageDesc = prometheus.NewDesc(
		"MemoryStats_ram_usage_bytes",
		"RAM usage as reported to the cluster manager.",
		[]string{"host"}, nil,
	)
)

func (cc MemoryStatsCollector) Describe(ch chan<- *prometheus.Desc) {
	prometheus.DescribeByCollect(cc, ch)
}

// Dev-note: Collect function is called whenever a get request is issued on /metrics endpoint
func (cc MemoryStatsCollector) Collect(ch chan<- prometheus.Metric) {

	cmd := "find . -name 'memstats.csv'"
	output, err := exec.Command("bash", "-c", cmd).Output()
	if err != nil {
		fmt.Println("Failed to execute command:", cmd)
	}

	outputString := strings.TrimSpace(string(output))

	if len(outputString) > 0 {

		filenames := strings.Split(string(outputString), "\n")

		fmt.Println("filenames", filenames, "Length of filenames", len(filenames))

		for number, filename := range filenames {
			fmt.Println("Line", number, "Filename: ", filename)

			parts := strings.Split(filename, "/")

			instanceID := "-1"

			if len(parts) == 2 { // Main thread, because filename will be ./memstats.csv, so length of parts will be 2
				fmt.Println("Collecting info about main thread")
				instanceID = "0" // Giving instance ID as 0 for main thread
				fmt.Println("Instance ID is", instanceID)
			} else if len(parts) == 3 { // Packet thread, because filename will be ./instance-*/memstats.csv, so length of parts will be 3
				fmt.Println("Collecting info about packet thread")
				instanceID = strings.Split(parts[1], "-")[1]
				fmt.Println("Instance ID is", instanceID)
			}

			file, err := os.Open(filename)
			if err != nil {
				fmt.Println("Couldn't open file: ", filename)
				log.Fatal(err)
			}
			defer file.Close()

			// Read memstats file line by line
			scanner := bufio.NewScanner(file)
			for scanner.Scan() {
				line := scanner.Text()
				split := strings.Split(line, ",")
				if len(split) == 4 { // Line in memstats will be of the form plugin,category,attribute,value

					extractedPlugin := split[0]
					extractedCategory := split[1]
					extractedAttribute := split[2]
					extractedValue := split[3]

					convertedValue, err := strconv.ParseFloat(extractedValue, 64)
					if err == nil {
						ch <- prometheus.MustNewConstMetric(
							prometheus.NewDesc(
								"memory_stat",
								"Memory stat",
								[]string{"plugin", "category", "attribute", "instanceID"},
								nil,
							),
							prometheus.GaugeValue,
							convertedValue,
							extractedPlugin,
							extractedCategory,
							extractedAttribute,
							instanceID,
						)
					} else {
						fmt.Println("Couldn't convert value", extractedValue, " to a float")
					}
				}
			}
		}
	}

	// Heap exporting

	cmd = "pgrep snort3 | head -n 1"
	snortpid, err := exec.Command("bash", "-c", cmd).Output()
	if err != nil {
		fmt.Println("Failed to execute command", cmd)
	}
	fmt.Println("Attempting to get heap memory")
	snortpidstring := strings.TrimSpace(string(snortpid))

	cmd = "tail /proc/" + snortpidstring + "/maps | grep \"heap\" | awk '{print $1}'"
	out, err := exec.Command("bash", "-c", cmd).Output()
	if err != nil {
		fmt.Println("Failed to execute command", cmd)
	}

	splitresult := strings.Split(strings.TrimSpace(string(out)), "-")

	if len(splitresult) > 0 {
		toinhex := splitresult[1]
		to, err := strconv.ParseInt(toinhex, 16, 0)
		if err != nil {
			fmt.Println("Couldn't convert hex value", to, " to integer")
			panic(err)
		}

		frominhex := splitresult[0]
		from, err := strconv.ParseInt(frominhex, 16, 0)
		if err != nil {
			fmt.Println("Couldn't convert hex value", from, " to integer")
			panic(err)
		}
		convertedValueForHeap := float64(to - from)

		ch <- prometheus.MustNewConstMetric(
			prometheus.NewDesc(
				"memory_stat",
				"Memory stat",
				[]string{"plugin", "category", "attribute", "instanceID"},
				nil,
			),
			prometheus.GaugeValue,
			convertedValueForHeap,
			"Heap",
			"Heap",
			"Heap",
			"Heap",
		)
	} else {
		fmt.Println("Not exporting heap data!\n")
	}

	// DU exporting

	cmd = "du -sh /dev/shm/snort"
	output2, err := exec.Command("bash", "-c", cmd).Output()
	if err != nil {
		fmt.Println("Failed to execute command", cmd)
	}
	fmt.Println(string(output2))
	outputString = strings.TrimSpace(string(output2))

	splitresult = strings.Split(strings.TrimSpace(outputString), "M")
	if len(splitresult) > 0 {
		convertedValueForDU, _ := strconv.ParseFloat(splitresult[0], 64)

		ch <- prometheus.MustNewConstMetric(
			prometheus.NewDesc(
				"memory_stat",
				"Memory stat",
				[]string{"plugin", "category", "attribute", "instanceID"},
				nil,
			),
			prometheus.GaugeValue,
			convertedValueForDU,
			"DU",
			"DU",
			"DU",
			"DU",
		)
	} else {
		fmt.Println("Not exporting DU data!\n")
	}

	// cgroups exporting

	cmd = "pmtool show CGroupsStatus | grep -A10 Detect | grep memory.usage_in_bytes | awk '{print $2}' | sed 's/,//g'"
	output3, err := exec.Command("bash", "-c", cmd).Output()
	if err != nil {
		fmt.Println("Failed to execute command", cmd)
	}
	fmt.Println(string(output3))
	outputString = strings.TrimSpace(string(output3))

	// fmt.Println(splitresult[0])
	if len(outputString) > 0 {
		convertedValueForcgroups, _ := strconv.ParseFloat(outputString, 64)

		ch <- prometheus.MustNewConstMetric(
			prometheus.NewDesc(
				"memory_stat",
				"Memory stat",
				[]string{"plugin", "category", "attribute", "instanceID"},
				nil,
			),
			prometheus.GaugeValue,
			convertedValueForcgroups,
			"Cgroups memory usage",
			"Cgroups memory usage",
			"Cgroups memory usage",
			"Cgroups memory usage",
		)
	} else {
		fmt.Println("Not exporting Cgroups memory usage data!\n")
	}

	// cgroups limits exporting

	cmd = "pmtool show CGroupsStatus | grep -A10 Detect | grep memory.limit_in_bytes | awk '{print $2}' | sed 's/,//g'"
	output4, err := exec.Command("bash", "-c", cmd).Output()
	if err != nil {
		fmt.Println("Failed to execute command", cmd)
	}
	fmt.Println(string(output4))
	outputString = strings.TrimSpace(string(output4))

	// fmt.Println(splitresult[0])
	if len(outputString) > 0 {
		convertedValueForcgroups, _ := strconv.ParseFloat(outputString, 64)

		ch <- prometheus.MustNewConstMetric(
			prometheus.NewDesc(
				"memory_stat",
				"Memory stat",
				[]string{"plugin", "category", "attribute", "instanceID"},
				nil,
			),
			prometheus.GaugeValue,
			convertedValueForcgroups,
			"Cgroups memory limit",
			"Cgroups memory limit",
			"Cgroups memory limit",
			"Cgroups memory limit",
		)
	} else {
		fmt.Println("Not exporting Cgroups memory limit data!\n")
	}

	// Mem Fail count

	cmd = "cat /dev/cgroups/memory/Detection/memory.failcnt"
	output6, err := exec.Command("bash", "-c", cmd).Output()
	if err != nil {
		fmt.Println("Failed to execute command", cmd)
	}
	fmt.Println(string(output6))
	outputString = strings.TrimSpace(string(output6))

	// fmt.Println(splitresult[0])
	if len(outputString) > 0 {
		convertedValueForMemFailCnt, _ := strconv.ParseFloat(outputString, 64)

		ch <- prometheus.MustNewConstMetric(
			prometheus.NewDesc(
				"memory_stat",
				"Memory stat",
				[]string{"plugin", "category", "attribute", "instanceID"},
				nil,
			),
			prometheus.GaugeValue,
			convertedValueForMemFailCnt,
			"Memory fail count",
			"Memory fail count",
			"Memory fail count",
			"Memory fail count",
		)
	} else {
		fmt.Println("Not exporting Memory fail count data!\n")
	}

	// Connection info

	cmd = "find . -name 'perf_monitor_base.csv'"
	output5, err := exec.Command("bash", "-c", cmd).Output()
	if err != nil {
		fmt.Println("Failed to execute command:", cmd)
	}

	outputString = strings.TrimSpace(string(output5))

	if len(outputString) > 0 {

		filenames := strings.Split(string(outputString), "\n")
		for number, filename := range filenames {
			fmt.Println("Line", number, "Filename", filename)

			parts := strings.Split(filename, "/")

			instanceID := "-1"

			if len(parts) == 3 { // Packet thread
				fmt.Println("Collecting connection info about packet thread")
				instanceID = strings.Split(parts[1], "-")[1]
				fmt.Println("Instance ID is", instanceID)
			}

			file, err := os.Open(filename)
			if err != nil {
				log.Fatal(err)
			}
			defer file.Close()

			cmd = "grep \"timestamp\" " + filename + " | tail -n 1"
			output6, err := exec.Command("bash", "-c", cmd).Output()
			if err != nil {
				fmt.Println("Failed to execute command", cmd)
			}
			fmt.Println(string(output6))
			outputString = strings.TrimSpace(string(output6))

			fields := strings.Split(outputString, ",")
			// fmt.Println("Fields", fields)

			cmd = "tail -n 1 " + filename
			output7, err := exec.Command("bash", "-c", cmd).Output()
			if err != nil {
				fmt.Println("Failed to execute command", cmd)
			}
			fmt.Println(string(output7))
			outputString = strings.TrimSpace(string(output7))

			values := strings.Split(outputString, ",")
			// fmt.Println("Values", values)

			if len(fields) != len(values) {
				fmt.Println("Not exporting connection info")
			} else {
				if values[0] == "#timestamp" {
					fmt.Println("No fresh values available")
				} else {
					for i := 0; i < len(fields); i++ {
						if strings.Contains(fields[i], "concurrent") {
							convertedValueForsession, _ := strconv.ParseFloat(values[i], 64)

							ch <- prometheus.MustNewConstMetric(
								prometheus.NewDesc(
									"memory_stat",
									"Memory stat",
									[]string{"plugin", "category", "attribute", "instanceID"},
									nil,
								),
								prometheus.GaugeValue,
								convertedValueForsession,
								"Connection",
								"Connection",
								fields[i],
								instanceID,
							)
						}
					}
				}
			}

		}
	}

}

func NewMemoryStats(zone string, reg prometheus.Registerer) *MemoryStats {
	c := &MemoryStats{
		Zone: zone,
	}
	cc := MemoryStatsCollector{MemoryStats: c}
	prometheus.WrapRegistererWith(prometheus.Labels{"zone": zone}, reg).MustRegister(cc)
	return c
}

func main() {
	// Since we are dealing with custom Collector implementations, it might
	// be a good idea to try it out with a pedantic registry.
	reg := prometheus.NewPedanticRegistry()

	// Construct cluster managers. In real code, we would assign them to
	// variables to then do something with cd ..them.
	NewMemoryStats("db", reg)

	// Add the standard process and Go metrics to the custom registry.
	reg.MustRegister(
		prometheus.NewProcessCollector(prometheus.ProcessCollectorOpts{}),
		prometheus.NewGoCollector(),
	)

	http.Handle("/metrics", promhttp.HandlerFor(reg, promhttp.HandlerOpts{}))
	log.Fatal(http.ListenAndServe(":8080", nil))
}
